YAWVOREX WEBSITE — VERSION 1 FRONT-END

Files
- index.html: the responsive single-file website. HTML, CSS, and JavaScript are included in this one file so it can be published on static hosting.

Included
- App-like multi-view interface with navigation that switches screens instead of making every menu item scroll to a section.
- Home, Services, Portfolio concepts, Shop preview, About, Process, Hire/Contact.
- Mobile navigation, visual transitions, product category filters, demo cart with browser localStorage, and enquiry form that prepares a downloadable text file.
- YAWVOREX brand styling and social links using the handles provided: Telegram @Yawvorx; TikTok, Facebook and Instagram @yawvorx.

Important limitations — read before public launch
- The portfolio entries are illustrative concepts, not completed client work.
- Store products and prices are demo data. Cart is browser-local only.
- No authentication, admin dashboard, database connection, server-side validation, real order storage, payment integration, or digital delivery is included in this static front-end.
- The contact form does not send data to a server; it makes a text file in the visitor's browser.
- Social profile URLs should be checked before advertising the site.
- Do not collect real customer payments or sensitive customer data with this version.

Deploying through GitHub Pages
1. Upload index.html to the root of a GitHub repository (the file must be named exactly index.html).
2. In repository Settings, open Pages.
3. Under Build and deployment, choose Deploy from a branch; select main and /(root), then Save.
4. Wait for GitHub Pages to publish and use the URL it provides.

A secure live shop/admin requires backend integration and separate testing; this front-end file does not pretend that those systems are finished.
